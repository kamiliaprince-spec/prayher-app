import { useState, useEffect } from "react";
import { Client, Account, Databases, ID } from "appwrite";
import PrayherShell from "./prayhershell";

const client = new Client()
  .setEndpoint("https://nyc.cloud.appwrite.io/v1")
  .setProject("69d6888d0017cf4f9910");

const account = new Account(client);
const databases = new Databases(client);

const DATABASE_ID = "69d689a7003a24c7813c";
const STREAK_COLLECTION_ID = "streaks";
const JOURNAL_COLLECTION_ID = "journal";

function AuthScreen({ onAuth }: { onAuth: () => void }) {
  const [isSignup, setIsSignup] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleAuth() {
    if (!email || !password) return;
    setLoading(true);
    setError("");
    try {
      if (isSignup) {
        await account.create(ID.unique(), email, password, name || undefined);
      }
      await account.createEmailSession(email, password);
      onAuth();
    } catch (err: any) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Crimson+Pro:ital,wght@0,400;0,600;0,700;1,400&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #FAF7F2; }
        input:focus { outline: none; border-color: #B8873C !important; }
      `}</style>

      <div style={{ maxWidth: 430, margin: "0 auto", minHeight: "100vh", background: "#FAF7F2", display: "flex", flexDirection: "column" }}>

        <div style={{ background: "linear-gradient(160deg, #4A2E12 0%, #7A5230 100%)", padding: "56px 32px 48px", borderRadius: "0 0 40px 40px", textAlign: "center" }}>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 38, color: "#FFFDF9", fontWeight: 700, margin: "0 0 8px" }}>
            Pray<span style={{ color: "#D4A855" }}>her</span>
          </h1>
          <p style={{ fontFamily: "'Crimson Pro', serif", fontSize: 16, color: "rgba(255,255,255,0.65)", margin: 0, fontStyle: "italic" }}>
            Helping her stay connected to God — daily.
          </p>
        </div>

        <div style={{ flex: 1, padding: "32px 24px 48px" }}>
          <div style={{ background: "#FFFCF7", borderRadius: 24, border: "1px solid #E8DDD0", padding: "28px 24px", marginBottom: 16 }}>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, color: "#4A2E12", margin: "0 0 6px", fontWeight: 700 }}>
              {isSignup ? "Create your account" : "Welcome back, sis 🤍"}
            </h2>
            <p style={{ fontFamily: "'Crimson Pro', serif", fontSize: 15, color: "#8A7060", margin: "0 0 24px" }}>
              {isSignup ? "Your spiritual journey starts here." : "God has been waiting for you."}
            </p>

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {isSignup && (
                <div>
                  <label style={{ fontFamily: "'Crimson Pro', serif", fontSize: 12, color: "#7A5230", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Your Name</label>
                  <input
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="What do we call you?"
                    style={{ width: "100%", border: "1.5px solid #E8DDD0", borderRadius: 12, padding: "12px 14px", fontFamily: "'Crimson Pro', serif", fontSize: 15, color: "#2E1F0E", background: "#FAF7F2" }}
                  />
                </div>
              )}

              <div>
                <label style={{ fontFamily: "'Crimson Pro', serif", fontSize: 12, color: "#7A5230", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  style={{ width: "100%", border: "1.5px solid #E8DDD0", borderRadius: 12, padding: "12px 14px", fontFamily: "'Crimson Pro', serif", fontSize: 15, color: "#2E1F0E", background: "#FAF7F2" }}
                />
              </div>

              <div>
                <label style={{ fontFamily: "'Crimson Pro', serif", fontSize: 12, color: "#7A5230", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  onKeyDown={e => e.key === "Enter" && handleAuth()}
                  style={{ width: "100%", border: "1.5px solid #E8DDD0", borderRadius: 12, padding: "12px 14px", fontFamily: "'Crimson Pro', serif", fontSize: 15, color: "#2E1F0E", background: "#FAF7F2" }}
                />
              </div>
            </div>

            {error && (
              <div style={{ background: "#F5DEDE", borderRadius: 10, padding: "10px 14px", marginTop: 12 }}>
                <p style={{ fontFamily: "'Crimson Pro', serif", fontSize: 14, color: "#B87070", margin: 0 }}>{error}</p>
              </div>
            )}

            <button
              onClick={handleAuth}
              disabled={loading}
              style={{ width: "100%", background: loading ? "#E8DDD0" : "linear-gradient(135deg, #B8873C, #D4A855)", border: "none", borderRadius: 14, padding: "14px 20px", fontFamily: "'Crimson Pro', serif", fontSize: 16, fontWeight: 700, color: "#FFFDF9", cursor: loading ? "not-allowed" : "pointer", marginTop: 20 }}>
              {loading ? "One moment..." : isSignup ? "Create Account 🙏" : "Login →"}
            </button>
          </div>

          <p
            onClick={() => { setIsSignup(!isSignup); setError(""); }}
            style={{ fontFamily: "'Crimson Pro', serif", fontSize: 15, color: "#8A7060", textAlign: "center", cursor: "pointer" }}>
            {isSignup ? "Already have an account? " : "New here? "}
            <span style={{ color: "#B8873C", fontWeight: 700 }}>
              {isSignup ? "Login" : "Create an account"}
            </span>
          </p>

          <p style={{ fontFamily: "'Playfair Display', serif", fontSize: 13, color: "#B8A898", textAlign: "center", marginTop: 32, fontStyle: "italic" }}>
            "She is clothed with strength and dignity."
          </p>
        </div>
      </div>
    </>
  );
}

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [streak, setStreak] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUser();
  }, []);

  async function checkUser() {
    try {
      const current = await account.get();
      setUser(current);
      await loadStreak(current.$id);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }

  async function loadStreak(userId: string) {
    try {
      const res = await databases.getDocument(DATABASE_ID, STREAK_COLLECTION_ID, userId);
      setStreak(res.count || 0);
    } catch {
      try {
        await databases.createDocument(DATABASE_ID, STREAK_COLLECTION_ID, userId, {
          userId,
          count: 0,
          lastDate: "",
        });
      } catch {}
      setStreak(0);
    }
  }

  async function checkIn() {
    if (!user) return;
    const todayStr = new Date().toDateString();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toDateString();

    try {
      const res = await databases.getDocument(DATABASE_ID, STREAK_COLLECTION_ID, user.$id);
      if (res.lastDate === todayStr) return;
      const newCount = res.lastDate === yesterdayStr ? res.count + 1 : 1;
      const updated = await databases.updateDocument(DATABASE_ID, STREAK_COLLECTION_ID, user.$id, {
        count: newCount,
        lastDate: todayStr,
      });
      setStreak(updated.count);
    } catch {
      try {
        const created = await databases.createDocument(DATABASE_ID, STREAK_COLLECTION_ID, user.$id, {
          userId: user.$id,
          count: 1,
          lastDate: todayStr,
        });
        setStreak(created.count);
      } catch {}
    }
  }

  async function logout() {
    await account.deleteSession("current");
    setUser(null);
    setStreak(0);
  }

  if (loading) {
    return (
      <>
        <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&display=swap'); * { margin: 0; padding: 0; box-sizing: border-box; } body { background: #FAF7F2; }`}</style>
        <div style={{ maxWidth: 430, margin: "0 auto", minHeight: "100vh", background: "linear-gradient(160deg, #4A2E12, #7A5230)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 38, color: "#FFFDF9", fontWeight: 700 }}>
            Pray<span style={{ color: "#D4A855" }}>her</span>
          </h1>
        </div>
      </>
    );
  }

  if (!user) {
    return <AuthScreen onAuth={checkUser} />;
  }

  return (
    <PrayherShell
      user={user}
      streak={streak}
      onCheckIn={checkIn}
      onLogout={logout}
      databases={databases}
      DATABASE_ID={DATABASE_ID}
      JOURNAL_COLLECTION_ID={JOURNAL_COLLECTION_ID}
    />
  );
}

